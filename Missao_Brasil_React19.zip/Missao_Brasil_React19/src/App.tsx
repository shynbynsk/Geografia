import { useCallback, useEffect, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Award, BookOpen, Clock3, Coins, Globe2, Medal, Play, RotateCcw, Star, Volume2, VolumeX, Speech, Speech as SpeechIcon, CheckCircle2, AlertTriangle } from 'lucide-react';
import questionData from './questions.json';

type Question = { q: string; options: string[]; answer: number; explanation: string; topic: string };
type Item = Question & { correct: string; choices: string[] };
type Phase = 'intro' | 'playing' | 'finished';
type Feedback = { correct: boolean; answer: string; explanation: string; unlockAt: number };
const BANK = questionData as Question[];
const TOTAL = 25;
const DURATION = 60 * 60 * 1000;
const ERROR_WAIT = 20 * 1000;
function shuffled<T>(items: T[]): T[] { const result = [...items]; for (let i = result.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [result[i], result[j]] = [result[j], result[i]]; } return result; }
function selectMission(): Item[] { return shuffled(BANK).slice(0, TOTAL).map(q => ({ ...q, correct: q.options[q.answer], choices: shuffled(q.options) })); }
function prettyTime(seconds: number) { return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`; }
function Globe() {
  const group = useRef<THREE.Group>(null);
  useFrame((_state, delta) => { if (group.current) group.current.rotation.y += delta * .18; });
  return <group ref={group} rotation={[.15, 0, .22]}>
    <mesh><sphereGeometry args={[1.05, 32, 32]} /><meshStandardMaterial color="#177c9e" metalness={.12} roughness={.55} /></mesh>
    <mesh scale={1.012}><sphereGeometry args={[1.05, 18, 12]} /><meshBasicMaterial color="#91eac1" wireframe transparent opacity={.22} /></mesh>
    <mesh rotation={[.7, .4, .1]}><torusGeometry args={[1.4, .018, 8, 90]} /><meshBasicMaterial color="#7ce3d5" /></mesh>
    <pointLight position={[2, 2, 3]} intensity={28} color="#8de6ff" />
  </group>;
}
function GlobeScene() { return <div className="h-44 sm:h-56 w-full" aria-hidden="true"><Canvas camera={{ position: [0, 0, 4], fov: 40 }} gl={{ alpha: true }}><ambientLight intensity={1.6} /><directionalLight position={[-2, 4, 3]} intensity={2} /><Globe /></Canvas></div>; }
function playTone(ok: boolean, enabled: boolean) {
  if (!enabled) return;
  try {
    const AudioContextClass = window.AudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const notes = ok ? [523.25, 659.25, 783.99] : [280, 220];
    notes.forEach((frequency, index) => {
      const osc = ctx.createOscillator(); const gain = ctx.createGain(); const start = ctx.currentTime + index * .12;
      osc.type = ok ? 'sine' : 'triangle'; osc.frequency.value = frequency;
      gain.gain.setValueAtTime(.0001, start); gain.gain.exponentialRampToValueAtTime(.12, start + .02); gain.gain.exponentialRampToValueAtTime(.0001, start + .22);
      osc.connect(gain); gain.connect(ctx.destination); osc.start(start); osc.stop(start + .23);
    });
    window.setTimeout(() => { void ctx.close(); }, 1000);
  } catch { /* Audio is optional when the browser blocks playback. */ }
}
function speak(text: string) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text); utterance.lang = 'pt-BR'; utterance.rate = .92;
  window.speechSynthesis.speak(utterance);
}
export default function App() {
  const [phase, setPhase] = useState<Phase>('intro');
  const [mission, setMission] = useState(0);
  const [questions, setQuestions] = useState<Item[]>([]);
  const [index, setIndex] = useState(0);
  const [hits, setHits] = useState(0);
  const [errors, setErrors] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(DURATION / 1000);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [waitLeft, setWaitLeft] = useState(0);
  const [timedOut, setTimedOut] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [speechEnabled, setSpeechEnabled] = useState(false);
  const deadline = useRef(0);
  const locked = useRef(false);
  const ended = useRef(false);
  const start = useCallback(() => {
    window.speechSynthesis?.cancel();
    deadline.current = Date.now() + DURATION; locked.current = false; ended.current = false;
    setMission(m => m + 1); setQuestions(selectMission()); setIndex(0); setHits(0); setErrors(0);
    setSecondsLeft(DURATION / 1000); setFeedback(null); setWaitLeft(0); setTimedOut(false); setPhase('playing');
  }, []);
  useEffect(() => {
    if (phase !== 'playing') return;
    const interval = window.setInterval(() => {
      const left = Math.max(0, Math.ceil((deadline.current - Date.now()) / 1000));
      setSecondsLeft(left);
      if (left === 0 && !ended.current) { ended.current = true; window.speechSynthesis?.cancel(); setFeedback(null); setTimedOut(true); setPhase('finished'); }
    }, 200);
    return () => window.clearInterval(interval);
  }, [phase]);
  useEffect(() => {
    if (!feedback || phase !== 'playing') return;
    const interval = window.setInterval(() => setWaitLeft(Math.max(0, Math.ceil((feedback.unlockAt - Date.now()) / 1000))), 150);
    return () => window.clearInterval(interval);
  }, [feedback, phase]);
  const current = questions[index];
  useEffect(() => { if (phase === 'playing' && speechEnabled && current && !feedback) speak(current.q); }, [phase, speechEnabled, current, feedback]);
  function answer(choice: string) {
    if (!current || feedback || locked.current || ended.current || Date.now() >= deadline.current) return;
    locked.current = true;
    const ok = choice === current.correct;
    if (ok) setHits(h => h + 1); else setErrors(e => e + 1);
    playTone(ok, soundEnabled);
    setWaitLeft(ok ? 0 : 20);
    setFeedback({ correct: ok, answer: current.correct, explanation: current.explanation, unlockAt: ok ? Date.now() : Date.now() + ERROR_WAIT });
  }
  function next() {
    if (!feedback || Date.now() < feedback.unlockAt || ended.current) return;
    window.speechSynthesis?.cancel();
    setFeedback(null); locked.current = false;
    if (index + 1 >= TOTAL) { ended.current = true; setTimedOut(false); setPhase('finished'); }
    else setIndex(i => i + 1);
  }
  return <main className="max-w-4xl mx-auto px-4 py-7 sm:py-12">
    <header className="flex flex-wrap items-center justify-between gap-3 mb-6"><div className="flex items-center gap-3 text-emerald-200 font-bold"><Globe2 size={26} /> MISSÃO BRASIL <span className="text-xs text-slate-300 font-medium">GEOGRAFIA • 5º ANO</span></div><div className="flex gap-2"><button title={soundEnabled ? 'Desligar sons' : 'Ligar sons'} aria-label="Alternar sons" onClick={() => setSoundEnabled(v => !v)} className="rounded-xl border border-slate-500 p-3">{soundEnabled ? <Volume2 size={19}/> : <VolumeX size={19}/>}</button><button title="Ativar ou desativar leitura em voz alta" aria-label="Alternar leitura em voz alta" onClick={() => {setSpeechEnabled(v => !v); window.speechSynthesis?.cancel();}} className={`rounded-xl border p-3 ${speechEnabled ? 'border-emerald-400 text-emerald-200' : 'border-slate-500'}`}><Speech size={19}/></button></div></header>
    {phase === 'intro' && <section className="glass p-6 sm:p-10 text-center"><GlobeScene /><h1 className="text-4xl sm:text-5xl font-black mb-3">Missão Brasil 🇧🇷</h1><p className="text-lg text-slate-200 mb-6">Explore a formação do povo brasileiro, a miscigenação e a diversidade cultural!</p><div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-7">{[['25','questões por missão'],['60 min','tempo total'],['20 s','revisão dos erros'],['⭐ + 🪙','prêmios por acerto']].map(([v,l])=><div key={l} className="rounded-xl bg-slate-900/70 p-3"><strong className="block text-2xl text-emerald-200">{v}</strong><span className="text-xs text-slate-300">{l}</span></div>)}</div><p className="text-slate-300 text-sm mb-6">Cada missão sorteia 25 perguntas diferentes de um banco com 50 questões. O cronômetro continua contando durante as explicações.</p><button className="action inline-flex gap-2 items-center" onClick={start}><Play size={20}/> Começar missão</button></section>}
    {phase === 'playing' && current && <section className="glass p-5 sm:p-9"><div className="flex justify-between items-center gap-2 mb-4 text-sm text-cyan-200 font-semibold"><span>🎯 MISSÃO {mission}</span><span>{current.topic}</span></div><div className="grid grid-cols-3 gap-2 mb-5 text-center">{[[<BookOpen size={19}/>, `${index + 1}/${TOTAL}`, 'Questão'],[<CheckCircle2 size={19}/>, `${hits}`, 'Acertos'],[<Clock3 size={19}/>, prettyTime(secondsLeft), 'Tempo']].map(([icon,val,label],i)=><div key={i} className="rounded-xl bg-slate-900/80 p-3"><div className="flex justify-center text-emerald-200 mb-1">{icon}</div><strong className={`text-xl sm:text-2xl block ${i===2 && secondsLeft<=300?'text-rose-300':''}`}>{val}</strong><small className="text-slate-300">{label}</small></div>)}</div><div className="flex justify-between text-sm text-amber-200 mb-3"><span className="flex gap-1 items-center"><Star size={17}/> {hits} estrelas</span><span className="flex gap-1 items-center"><Coins size={17}/> {hits * 10} moedas</span></div><div className="h-3 rounded-full bg-slate-950 overflow-hidden mb-8"><div className="h-full bg-emerald-400 transition-all" style={{width:`${index / TOTAL * 100}%`}}/></div><h2 className="text-xl sm:text-3xl font-bold mb-7 leading-snug">{current.q}</h2><div className="grid gap-3">{current.choices.map((choice,i)=><button key={choice} disabled={!!feedback} onClick={() => answer(choice)} className="choice"><strong className="mr-2 text-emerald-200">{String.fromCharCode(65+i)})</strong>{choice}</button>)}</div></section>}
    {phase === 'finished' && <section className="glass p-7 sm:p-10 text-center"><Medal size={70} className="text-amber-300 mx-auto mb-4"/><h1 className="text-3xl font-black mb-3">{timedOut ? '⏰ Tempo esgotado!' : `🏆 Missão ${mission} concluída!`}</h1><p className="text-slate-200 mb-6">Você respondeu {hits + errors} de {TOTAL} perguntas.</p><div className="grid grid-cols-2 gap-3 mb-6">{[[`${hits}`,'Acertos'],[`${errors}`,'Erros'],[`${hits + errors ? Math.round(hits/(hits+errors)*100):0}%`,'Aproveitamento'],[`${hits * 10} 🪙`,'Moedas ganhas']].map(([v,l])=><div className="bg-slate-900/70 rounded-xl p-4" key={l}><strong className="text-3xl text-emerald-200 block">{v}</strong><small>{l}</small></div>)}</div><p className="text-amber-200 mb-6">⭐ Você conquistou {hits} {hits===1?'estrela':'estrelas'}!</p><button className="action inline-flex gap-2 items-center" onClick={start}><RotateCcw size={19}/> Nova missão</button></section>}
    {feedback && phase === 'playing' && <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 p-4" role="dialog" aria-modal="true" aria-labelledby="feedback-title"><div className="glass reward max-w-xl w-full p-7 sm:p-10 text-center" key={`${index}-${feedback.correct}`}><div className="flex justify-center mb-4">{feedback.correct ? <Award size={75} className="text-yellow-300"/> : <AlertTriangle size={75} className="text-orange-300"/>}</div><h2 id="feedback-title" className={`text-3xl font-black mb-4 ${feedback.correct?'text-emerald-200':'text-orange-200'}`}>{feedback.correct?'🎉 Parabéns!':'⚠️ Atenção! Vamos aprender!'}</h2>{feedback.correct ? <p className="text-2xl text-yellow-200 font-bold mb-3">+1 ⭐ estrela e +10 🪙 moedas!</p> : <p className="text-lg mb-3">Resposta correta: <strong className="text-emerald-200">{feedback.answer}</strong></p>}<p className="text-slate-100 text-lg leading-relaxed mb-6">{feedback.explanation}</p>{!feedback.correct && <p aria-live="polite" className="mb-4 text-orange-200">Leia a explicação. Você poderá continuar em {waitLeft} segundos.</p>}<button className="action" disabled={waitLeft > 0} onClick={next}>{waitLeft > 0 ? `Aguarde ${waitLeft}s` : 'Continuar ➜'}</button></div></div>}
    <footer className="text-center text-xs text-slate-400 mt-6">Tecnologias: React 19 • TypeScript • Tailwind CSS v4 • Three.js • Web Audio API • Web Speech API</footer>
  </main>;
}
